import cv2
import numpy as np
from random import randint, uniform
import string, random
import os


def Blur(img, kw, kh):
    return cv2.blur(img, (kw, kh))


def generate_text(chars, size = 8):
    return ''.join(random.choice(chars) for _ in range(size))


def addText(img, chars, font, size, line_size):

    text = generate_text(chars, 1)    

    cv2.putText(img, text, (0, img.shape[0]-4), font, size, (0, 0, 255), line_size, cv2.LINE_AA)

    return text

S = [(70,58),(40,35),(75,70),(70,70),(70,70),(50,50)]


def Noise(image):    
    row,col = image.shape
    s_vs_p = 0.4
    amount = 0.01
    out = np.copy(image)
    

    salt = np.ceil(amount * image.size * s_vs_p)
    coords = [np.random.randint(0, i - 1, int(salt))
          for i in image.shape]
    out[coords] = 1

    pepper = np.ceil(amount* image.size * (1. - s_vs_p))
    coords = [np.random.randint(0, i - 1, int(pepper)) for i in image.shape]
    out[coords] = 0
    return out

def genSymbolImg(chars = string.ascii_uppercase + string.digits,
                font = None,
                line_size = None,
                blur = None,
                kw = None, 
                kh = None):

    if font is None:
        font = randint(0, 5)

    if line_size is None:
        line_size = randint(1, 3)

    if blur is None:
        blur = randint(0, 1)

    if kw is None:
        kw = randint(3, 9)

    if kh is None:
        kh = randint(3, 9)


    genImg = np.full(S[font], 255, dtype= np.uint8)

    text = addText(genImg, chars, font, 3, line_size)

    if randint(0, 1):
        genImg = Noise(genImg)

    if blur:
        genImg = Blur(genImg, kw, kh)


    return genImg, text


cnt = [0 for i in range(1000)]

if __name__ == '__main__':

    os.chdir('dataset')
    for i in xrange(1000):
        img, text = genSymbolImg(kw = 5, kh = 5, blur = 1)
        if not os.path.exists(text):
            os.mkdir(text)
        os.chdir(text)
        cnt[ord(text)] = cnt[ord(text)] + 1
        cv2.imwrite('./'+ str(cnt[ord(text)]) + ".jpg", img)
        os.chdir('..')

        cv2.imshow("W", img)
